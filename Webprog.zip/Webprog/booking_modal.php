<?php
// booking_modal.php
?>

<div class="modal fade" id="bookingModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">

    <form method="POST"
          action="book_appointment.php"
          class="modal-content p-4"
          style="border-radius: 25px; border: 2px solid var(--hp-light-green);">

      <!-- Header -->
      <div class="modal-header border-0 pb-2">
        <h5 class="modal-title" style="color: var(--hp-dark-green);">
          📅 Book Appointment
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <!-- Body -->
      <div class="modal-body pt-0">

        <!-- Hidden doctor ID -->
        <input type="hidden" name="doctor_id" id="doctorIdInput">

        <!-- Date -->
        <div class="mb-3">
          <label class="form-label">Select Date</label>
          <input type="date"
                 name="appointment_date"
                 id="appointmentDate"
                 class="form-control rounded-pill"
                 required>
        </div>

        <!-- Time -->
        <div class="mb-3">
          <label class="form-label">Select Time</label>
          <select name="appointment_time"
                  id="appointmentTime"
                  class="form-select rounded-pill"
                  required>
            <option value="">Select a time slot</option>
          </select>
          <small class="text-muted ms-2">
            Only available time slots are shown.
          </small>
        </div>

      </div>

      <!-- Footer -->
      <div class="modal-footer border-0 pt-0 d-flex justify-content-end gap-2">
        <button type="button"
                class="btn btn-light rounded-pill px-4"
                data-bs-dismiss="modal">
          Cancel
        </button>

        <button type="submit"
                class="btn option-card px-4 py-2 border-0"
                style="background-color: var(--hp-dark-green) !important; color: white !important;">
          Confirm Booking
        </button>
      </div>

    </form>

  </div>
</div>

<!-- ✅ Booking Success Toast -->
<div class="position-fixed bottom-0 end-0 p-3" style="z-index: 1055;">
  <div id="bookingToast" class="toast align-items-center text-bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="d-flex">
      <div class="toast-body">
        ✔️ Your appointment has been booked successfully!
      </div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
  </div>
</div>
