<?php
include("database.php");

$doctorId = $_GET['doctor_id'];
$date = $_GET['date'];

$blocked = [];

$query = "
    SELECT ScheduledDate
    FROM appointments
    WHERE DoctorID = ?
      AND DATE(ScheduledDate) = ?
      AND Status IN ('Pending', 'Confirmed')
";

$stmt = $conn->prepare($query);
$stmt->bind_param("is", $doctorId, $date);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $blocked[] = date("H:i", strtotime($row['ScheduledDate']));
}

echo json_encode($blocked);
