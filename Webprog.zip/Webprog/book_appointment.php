<?php
session_start();
include("database.php");

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $patientId = $_SESSION["user_id"];
    $doctorId  = $_POST["doctor_id"];
    $date      = $_POST["appointment_date"];
    $time      = $_POST["appointment_time"];

    // Combine date + time into DATETIME
    $scheduledDateTime = $date . ' ' . $time . ':00';

    // 1️⃣ Prevent past date/time (server-side safety)
    if (strtotime($scheduledDateTime) <= time()) {
        die("Invalid appointment time.");
    }

    // 2️⃣ Prevent booking already taken slots (Pending or Confirmed)
    $checkQuery = "
        SELECT AppointmentID
        FROM appointments
        WHERE DoctorID = ?
          AND ScheduledDate = ?
          AND Status IN ('Pending', 'Confirmed')
        LIMIT 1
    ";

    $checkStmt = $conn->prepare($checkQuery);
    $checkStmt->bind_param("is", $doctorId, $scheduledDateTime);
    $checkStmt->execute();
    $checkStmt->store_result();

    if ($checkStmt->num_rows > 0) {
        die("This time slot is no longer available.");
    }

    // 3️⃣ Insert appointment
    $insertQuery = "
        INSERT INTO appointments
        (PatientID, DoctorID, ScheduledDate, Status, CreatedAt)
        VALUES (?, ?, ?, 'Pending', NOW())
    ";

    $stmt = $conn->prepare($insertQuery);
    $stmt->bind_param("iis", $patientId, $doctorId, $scheduledDateTime);

    if ($stmt->execute()) {
        header("Location: mainscreen.php?appointment=success");
        exit;
    } else {
        echo "Error booking appointment.";
    }
}
