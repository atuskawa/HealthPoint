// ====== GLOBAL ATTACHMENT ======
window.startConsult = startConsult;
window.answerFollowUp = answerFollowUp;

// ====== STATE ======
let currentSymptom = null;
let followUpStep = 0;
let answers = [];

// ====== FOLLOW-UP QUESTIONS DATA ======
const followUps = {
    Headache: [
        { question: "Currently, how intense is your headache?", options: ["Mild", "Moderate", "Severe"] },
        { question: "Are you experiencing nausea or light sensitivity?", options: ["Yes", "No"] },
        { question: "How long has the headache persisted?", options: ["< 1 day", "1-3 days", "> 3 days"] }
    ],
    Fever: [
        { question: "How many days have you had this fever?", options: ["Less than 3 days", "More than 3 days"] },
        { question: "Have you noticed chills, body aches, or sweating along with the fever?", options: ["Yes", "No"] }
    ],
    Nausea: [
        { question: "How severe is your nausea at the moment?", options: ["Mild", "Moderate", "Severe"] },
        { question: "Have you vomited within the past 24 hours?", options: ["Yes", "No"] }
    ],
    Fatigue: [
        { question: "How would you describe your level of fatigue?", options: ["Constant", "Comes and Goes"] },
        { question: "Is the fatigue affecting your daily tasks?", options: ["Yes", "No"] },
        { question: "Are you experiencing muscle pain, dizziness, or weakness along with the fatigue?", options: ["Yes", "No"] }
    ]
};

// ====== ENTRY POINT ======
function startConsult(symptom) {
    currentSymptom = symptom;
    followUpStep = 0;
    answers = [];

    const chat = document.getElementById("chat-window");
    const loader = document.getElementById("ai-loading");

    chat.innerHTML += `<div class="text-end mb-2">
        <span class="badge rounded-pill bg-light text-dark p-2 border">Patient: ${symptom}</span>
    </div>`;
    loader.classList.remove("d-none");

    setTimeout(() => {
        loader.classList.add("d-none");
        showNextFollowUp();
    }, 1200);
}

function showNextFollowUp() {
    const chat = document.getElementById("chat-window");
    const container = document.getElementById("option-buttons");
    const currentFollowUps = followUps[currentSymptom];

    if (!currentFollowUps || followUpStep >= currentFollowUps.length) {
        showFinalReport();
        return;
    }

    const followUp = currentFollowUps[followUpStep];
    chat.innerHTML += `
        <div class="bot-response p-3 mb-3 border-start border-4 border-success bg-light">
            <strong>HealthPoint Bot:</strong><br>${followUp.question}
        </div>`;

    container.innerHTML = followUp.options.map(option => 
        `<div class="col-md-4 mb-2">
            <button class="option-card w-100 py-3" onclick="answerFollowUp('${option}')">${option}</button>
        </div>`).join("");

    chat.scrollTop = chat.scrollHeight;
}

function answerFollowUp(answer) {
    const chat = document.getElementById("chat-window");
    const container = document.getElementById("option-buttons");
    const loader = document.getElementById("ai-loading");

    chat.innerHTML += `<div class="text-end mb-2"><span class="badge rounded-pill bg-success text-white p-2">${answer}</span></div>`;
    container.innerHTML = "";
    loader.classList.remove("d-none");

    answers.push(answer);
    followUpStep++;

    setTimeout(() => {
        loader.classList.add("d-none");
        showNextFollowUp();
    }, 800);
}

function showFinalReport() {
    const chat = document.getElementById("chat-window");
    const loader = document.getElementById("ai-loading");
    loader.classList.remove("d-none");

    setTimeout(() => {
        loader.classList.add("d-none");
        let report = "";

        if (currentSymptom === "Headache") {
            report = (answers.includes("Severe") || answers.includes("Yes")) ? 
                "<strong>Notice:</strong> Your headache symptoms may require urgent evaluation." : 
                "<strong>Plan:</strong> Prioritize rest and hydration.";
        } else if (currentSymptom === "Fever") {
            report = (answers.includes("More than 3 days") || answers.includes("Yes")) ? 
                "<strong>Notice:</strong> A persistent fever warrants a consultation." : 
                "<strong>Plan:</strong> Monitor temperature and rest.";
        } else if (currentSymptom === "Nausea") {
            report = (answers.includes("Severe") || answers.includes("Yes")) ? 
                "<strong>Notice:</strong> Persistent nausea poses a risk of dehydration." : 
                "<strong>Plan:</strong> Maintain clear fluids.";
        } else if (currentSymptom === "Fatigue") {
            report = (answers.includes("Yes") || answers.includes("Constant")) ? 
                "<strong>Notice:</strong> Debilitating fatigue should be evaluated." : 
                "<strong>Plan:</strong> Ensure consistent sleep hygiene.";
        }

        chat.innerHTML += `
            <div class="bot-response p-3 mb-2 border-start border-4 border-primary bg-white shadow-sm">
                <strong>HealthPoint Report:</strong><br>${report}<hr>
                <div class="text-center"><button class="btn-reset-triage" onclick="location.reload()">Reset</button></div>
            </div>`;
        chat.scrollTop = chat.scrollHeight;
    }, 1200);
}

// ====== BOOKING MODAL & TIME SLOTS ======
const timeSlots = [];
for (let hour = 7; hour <= 16; hour++) {
    const hh = hour.toString().padStart(2, '0');
    timeSlots.push(`${hh}:00`);
}

function populateTimeDropdown() {
    const dateInput = document.getElementById('appointmentDate');
    const timeSelect = document.getElementById('appointmentTime');
    const doctorIdInput = document.getElementById('doctorIdInput');

    if (!dateInput || !dateInput.value) return;

    const selectedDate = dateInput.value;
    const now = new Date();
    const todayStr = now.toISOString().split("T")[0];
    const isToday = selectedDate === todayStr;

    timeSelect.innerHTML = '<option value="">Select a time slot</option>';

    timeSlots.forEach(time => {
        const [hourStr] = time.split(":");
        const hour = parseInt(hourStr, 10);
        const slotDateTime = new Date(selectedDate);
        slotDateTime.setHours(hour, 0, 0, 0);

        if (isToday && slotDateTime.getTime() < now.getTime()) return;

        const option = document.createElement("option");
        option.value = time;
        option.textContent = time;
        timeSelect.appendChild(option);
    });

    const doctorId = doctorIdInput.value;
    fetch(`get_booked_slots.php?doctor_id=${doctorId}&date=${selectedDate}`)
        .then(res => res.json())
        .then(blockedTimes => {
            [...timeSelect.options].forEach(option => {
                if (blockedTimes.includes(option.value)) {
                    option.disabled = true;
                    option.textContent += " (Unavailable)";
                }
            });
        })
        .catch(err => console.error("Error fetching booked slots:", err));
}

function openBookingModal(doctorId) {
    document.getElementById('doctorIdInput').value = doctorId;
    const dateInput = document.getElementById('appointmentDate');
    const today = new Date().toISOString().split("T")[0];
    dateInput.min = today;
    dateInput.value = today;
    populateTimeDropdown();
    new bootstrap.Modal(document.getElementById('bookingModal')).show();
}

// ====== EVENT LISTENERS ======
document.addEventListener('DOMContentLoaded', () => {

    // Sidebar
    const toggle = document.getElementById('sidebarToggle');
    const sidebar = document.querySelector('.hp-sidebar');
    if (toggle && sidebar) {
        if (localStorage.getItem('hp_sidebar_collapsed') === '1') sidebar.classList.add('collapsed');
        toggle.addEventListener('click', () => {
            sidebar.classList.toggle('collapsed');
            localStorage.setItem('hp_sidebar_collapsed', sidebar.classList.contains('collapsed') ? '1' : '0');
        });
    }

    // Date change for booking
    const dateInput = document.getElementById('appointmentDate');
    if (dateInput) dateInput.addEventListener('change', populateTimeDropdown);

    // Settings Save Button
    document.getElementById('saveSettingsBtn')?.addEventListener('click', function() {
        const btn = this;
        const originalText = btn.innerHTML;
        btn.innerHTML = "Saving...";
        btn.disabled = true;
        setTimeout(() => {
            alert("✔️ Settings saved successfully!");
            btn.innerHTML = originalText;
            btn.disabled = false;
        }, 800); 
    });

    // ====== BOOKING SUCCESS TOAST ======
    const urlParams = new URLSearchParams(window.location.search); {
    if (urlParams.get('appointment') === 'success') {
        const toastEl = document.getElementById('bookingToast');
        if (toastEl) {
            const toast = new bootstrap.Toast(toastEl, { delay: 3000 });
            toast.show();

            const cleanUrl = window.location.href.split("?")[0];
                window.history.replaceState({}, document.title, cleanUrl);
            }
        }
    }
});
