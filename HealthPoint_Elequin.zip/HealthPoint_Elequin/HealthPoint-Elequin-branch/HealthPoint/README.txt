Further Improvements:
Yung API ng GPT or Gemini para sa Bot

Kulang:
Backend
Saving user information
