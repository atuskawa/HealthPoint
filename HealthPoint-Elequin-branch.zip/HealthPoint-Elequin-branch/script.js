// ====== GLOBAL ATTACHMENT ======
// This prevents the "startConsult is not defined" error
window.startConsult = startConsult;
window.answerFollowUp = answerFollowUp;

// ====== STATE ======
let currentSymptom = null;
let followUpStep = 0;
let answers = []; // Moved here to ensure global access

// ====== ENTRY POINT ======
function startConsult(symptom) {
    currentSymptom = symptom;
    followUpStep = 0;
    answers = []; // RESET ANSWERS EVERY TIME A NEW CONSULT STARTS

    const chat = document.getElementById("chat-window");
    const loader = document.getElementById("ai-loading");

    chat.innerHTML += `<div class="text-end mb-2">
        <span class="badge rounded-pill bg-light text-dark p-2 border">Patient: ${symptom}</span>
    </div>`;
    loader.classList.remove("d-none");

    setTimeout(() => {
        loader.classList.add("d-none");
        showNextFollowUp();
    }, 1200);
}

// ====== FOLLOW-UP QUESTIONS DATA ======
const followUps = {
    Headache: [
        { question: "Currently, how intense is your headache?", options: ["Mild", "Moderate", "Severe"] },
        { question: "Are you experiencing nausea or light sensitivity?", options: ["Yes", "No"] },
        { question: "How long has the headache persisted?", options: ["< 1 day", "1-3 days", "> 3 days"] }
    ],
    Fever: [
        { question: "How many days have you had this fever?", options: ["Less than 3 days", "More than 3 days"] },
        { question: "Have you noticed chills, body aches, or sweating along with the fever?", options: ["Yes", "No"] }
    ],
    Nausea: [
        { question: "How severe is your nausea at the moment?", options: ["Mild", "Moderate", "Severe"] },
        { question: "Have you vomited within the past 24 hours?", options: ["Yes", "No"] }
    ],
    Fatigue: [
        { question: "How would you describe your level of fatigue?", options: ["Constant", "Comes and Goes"] },
        { question: "Is the fatigue affecting your daily tasks?", options: ["Yes", "No"] },
        { question: "Are you experiencing muscle pain, dizziness, or weakness along with the fatigue?", options: ["Yes", "No"] }
    ]
};

function showNextFollowUp() {
    const chat = document.getElementById("chat-window");
    const container = document.getElementById("option-buttons");
    const currentFollowUps = followUps[currentSymptom];

    if (!currentFollowUps || followUpStep >= currentFollowUps.length) {
        showFinalReport();
        return;
    }

    const followUp = currentFollowUps[followUpStep];
    chat.innerHTML += `
        <div class="bot-response p-3 mb-3 border-start border-4 border-success bg-light">
            <strong>HealthPoint Bot:</strong><br>${followUp.question}
        </div>`;

    container.innerHTML = followUp.options.map(option => 
        `<div class="col-md-4 mb-2">
            <button class="option-card w-100 py-3" onclick="answerFollowUp('${option}')">${option}</button>
        </div>`).join("");

    chat.scrollTop = chat.scrollHeight;
}

function answerFollowUp(answer) {
    const chat = document.getElementById("chat-window");
    const container = document.getElementById("option-buttons");
    const loader = document.getElementById("ai-loading");

    chat.innerHTML += `<div class="text-end mb-2"><span class="badge rounded-pill bg-success text-white p-2">${answer}</span></div>`;
    container.innerHTML = "";
    loader.classList.remove("d-none");

    answers.push(answer);
    followUpStep++;

    setTimeout(() => {
        loader.classList.add("d-none");
        showNextFollowUp();
    }, 800);
}

function showFinalReport() {
    const chat = document.getElementById("chat-window");
    const loader = document.getElementById("ai-loading");
    loader.classList.remove("d-none");

    setTimeout(() => {
        loader.classList.add("d-none");
        let report = "";

        if (currentSymptom === "Headache") {
            report = (answers.includes("Severe") || answers.includes("Yes")) ? 
                "<strong>Notice:</strong> Your headache symptoms may require urgent evaluation. Please monitor for vision changes, weakness, or confusion." : 
                "<strong>Plan:</strong> Prioritize rest and hydration. Consider over-the-counter relief if symptoms persist.";
        } else if (currentSymptom === "Fever") {
            report = (answers.includes("More than 3 days") || answers.includes("Yes")) ? 
                "<strong>Notice:</strong> A persistent fever warrants a consultation with a healthcare provider to rule out infection." : 
                "<strong>Plan:</strong> Monitor your temperature regularly, maintain fluid intake, and rest.";
        } else if (currentSymptom === "Nausea") {
            report = (answers.includes("Severe") || answers.includes("Yes")) ? 
                "<strong>Notice:</strong> Persistent nausea or vomiting poses a risk of dehydration. Clinical evaluation is recommended." : 
                "<strong>Plan:</strong> Maintain small, frequent sips of clear fluids and monitor for further digestive distress.";
        } else if (currentSymptom === "Fatigue") {
            report = (answers.includes("Yes") || answers.includes("Constant")) ? 
                "<strong>Notice:</strong> Chronic or debilitating fatigue should be evaluated by a professional to investigate potential underlying causes." : 
                "<strong>Plan:</strong> Ensure consistent sleep hygiene (7-9 hours) and track energy levels relative to physical activity.";
        }

        chat.innerHTML += `
            <div class="bot-response p-3 mb-2 border-start border-4 border-primary bg-white shadow-sm">
                <strong>HealthPoint Report:</strong><br>${report}<hr>
                <div class="text-center"><button class="btn-reset-triage" onclick="location.reload()">Reset</button></div>
            </div>`;
        chat.scrollTop = chat.scrollHeight;
    }, 1200);
}

// ====== SIDEBAR TOGGLE ======
document.addEventListener('DOMContentLoaded', () => {
    const toggle = document.getElementById('sidebarToggle');
    const sidebar = document.querySelector('.hp-sidebar');
    if (!toggle || !sidebar) return;

    if (localStorage.getItem('hp_sidebar_collapsed') === '1') sidebar.classList.add('collapsed');

    toggle.addEventListener('click', () => {
        sidebar.classList.toggle('collapsed');
        localStorage.setItem('hp_sidebar_collapsed', sidebar.classList.contains('collapsed') ? '1' : '0');
    });
});


// ====== SETTINGS SAVE BUTTON (Remove nalang if maglalagay sa SQL ng save option)======
document.getElementById('saveSettingsBtn').addEventListener('click', function() {
    // 1. Visual feedback: Disable button so they don't spam it
    const btn = this;
    const originalText = btn.innerHTML;
    btn.innerHTML = "Saving...";
    btn.disabled = true;

    // 2. Simulate a save delay (makes it look like it's actually talking to a database)
    setTimeout(() => {
        // 3. The JS Popup
        alert("✔️ Settings saved successfully!");

        // 4. Reset the button
        btn.innerHTML = originalText;
        btn.disabled = false;
    }, 800); 
});